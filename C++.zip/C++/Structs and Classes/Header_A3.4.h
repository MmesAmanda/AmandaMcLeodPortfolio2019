
#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

class Sports {


public:
    string Sports1();
    string Sports2();
    string Sports3();

    Sports();
    ~Sports();


    string GetSName();
    void SetSName(string SName);

    string GetAbbreviation();
    void SetAbbreviation(string Abbreviation);

    string GetCountryOrigin();
    void SetCountryOrigin(string CountryOrigin);

    void MakePuck();
    void MakeBall();
    void MakeFootball();
    void gotoXY(int x, int y);


private:
    string m_SName;
    string m_Abbreviation;
    string m_CountryOrigin;


};
