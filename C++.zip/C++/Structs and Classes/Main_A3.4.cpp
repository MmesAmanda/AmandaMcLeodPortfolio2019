#include "Header_A3.4.h" 

void gotoXY(int x, int y);
void MakePuck();
void MakeBall();
void MakeFootball();

int main()
{

    gotoXY(0, 0);
    int Option;

    cout << "Please select an Option (1,2,3):" << endl;

    Sports mySports[9];


    mySports[0].SetSName("1.Hockey");
    mySports[1].SetSName("2.Baseball");
    mySports[2].SetSName("3.Football - Panda game = win");


    cout << mySports[0].GetSName() << endl;
    cout << mySports[1].GetSName() << endl;
    cout << mySports[2].GetSName() << endl;



    cin >> Option;
    //Option = Option - 1;

    switch (Option)
    {
    case 1:
        //print abb.
        mySports[3].SetAbbreviation("NHL");
        cout << "Current League Abbreviation:" << mySports[3].GetAbbreviation() << endl;

        //print country of O
        mySports[4].SetCountryOrigin("Canada");
        cout << "Country of Origin:" << mySports[4].GetCountryOrigin() << endl;

        //function to make ascii ball
        MakePuck();
        Sleep(2000);
        break;
    case 2:
        //print abb.
        mySports[5].SetAbbreviation("MLB");
        cout << "Current League Abbreviation:" << mySports[5].GetAbbreviation() << endl;

        //print country of O
        mySports[6].SetCountryOrigin("United States of America");
        cout << "Country of Origin:" << mySports[6].GetCountryOrigin() << endl;

        //function to make ascii ball
        MakeBall();
        Sleep(2000);
        break;
    case 3:
        //print abb.
        mySports[7].SetAbbreviation("NFL");
        cout << "Current League Abbreviation:" << mySports[7].GetAbbreviation() << endl;

        //print country of O
        mySports[8].SetCountryOrigin("Britain");
        cout << "Country of Origin:" << mySports[8].GetCountryOrigin() << endl;

        //function to make ascii ball
        MakeFootball();
        Sleep(2000);
        break;
    }


    system("pause");

    return 0;
}

void MakePuck()
{
    gotoXY(6, 10);
    cout << (char)248;
    gotoXY(2, 11);
    cout << (char)248;
    gotoXY(10, 11);
    cout << (char)248;
    gotoXY(0, 12);
    cout << (char)248;
    gotoXY(12, 12);
    cout << (char)248;
    gotoXY(2, 13);
    cout << (char)248;
    gotoXY(10, 13);
    cout << (char)248;
    gotoXY(6, 14);
    cout << (char)248;
    gotoXY(0, 14);
    cout << (char)248;
    gotoXY(1, 15);
    cout << (char)248;
    gotoXY(3, 16);
    cout << (char)248;
    gotoXY(6, 16);
    cout << (char)248;
    gotoXY(9, 16);
    cout << (char)248;
    gotoXY(11, 15);
    cout << (char)248;
    gotoXY(12, 14);
    cout << (char)248 <<endl <<endl << endl <<endl <<endl;
}

void MakeBall()
{
    gotoXY(6, 10);
    cout << (char)248;
    gotoXY(1, 11);
    cout << (char)248;
    gotoXY(11, 11);
    cout << (char)248;
    gotoXY(0, 13);
    cout << (char)248;
    gotoXY(12, 13);
    cout << (char)248;
    gotoXY(1, 15);
    cout << (char)248;
    gotoXY(11, 15);
    cout << (char)248;
    gotoXY(6, 16);
    cout << (char)248;

    //Stitches on Baseball
    gotoXY(3, 12);
    cout << (char)248;
    gotoXY(4, 13);
    cout << (char)248;
    gotoXY(3, 14);
    cout << (char)248;
    gotoXY(8, 12);
    cout << (char)248;
    gotoXY(7, 13);
    cout << (char)248;
    gotoXY(8, 14);
    cout << (char)248 << endl << endl << endl << endl;

    Sleep(2000);

}

void MakeFootball()
{
    gotoXY(6, 10);
    cout << (char)248;
    gotoXY(2, 11);
    cout << (char)248;
    gotoXY(3, 11);
    cout << (char)248;
    gotoXY(4, 11);
    cout << (char)248;
    gotoXY(5, 11);
    cout << (char)248;
    gotoXY(6, 11);
    cout << (char)248;
    gotoXY(7, 11);
    cout << (char)248;
    gotoXY(8, 11);
    cout << (char)248;
    gotoXY(9, 11);
    cout << (char)248;
    gotoXY(10, 11);
    cout << (char)248;
    gotoXY(0, 12);
    cout << (char)248;
    gotoXY(12, 12);
    cout << (char)248;
    gotoXY(1, 13);
    cout << (char)248;
    gotoXY(3, 14);
    cout << (char)248;
    gotoXY(6, 14);
    cout << (char)248;
    gotoXY(9, 14);
    cout << (char)248;
    gotoXY(11, 13);
    cout << (char)248 << endl << endl << endl << endl << endl;
    
}

void gotoXY(int x, int y)
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
