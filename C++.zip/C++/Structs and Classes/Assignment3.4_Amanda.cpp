/*
Title: Assignment-3
Author: Amanda McLeod
Objective: create a class with different sports, have an extra method that gives user option
to output what this sports ball looks like in ascii, also discover the country of origin of the
sport and the abbreviation of the highest league level

*/

#include "Header_A3.4.h"

Sports::Sports()
{
    m_SName = "";
    m_Abbreviation = "";
    m_CountryOrigin = "";

}

Sports::~Sports()
{
    m_SName = "";
    m_Abbreviation = "";
    m_CountryOrigin = "";
}



#pragma region Getters 
string Sports::GetSName()
{
    return m_SName;
}
string Sports::GetAbbreviation()
{
    return m_Abbreviation;
}
string Sports::GetCountryOrigin()
{
    return m_CountryOrigin;
}
#pragma endregion

void Sports::SetSName(string SName)
{
    m_SName = SName;
}

void Sports::SetAbbreviation(string Abbreviation)
{
    m_Abbreviation = Abbreviation;
}

void Sports::SetCountryOrigin(string CountryOrigin)
{
    m_CountryOrigin = CountryOrigin;
}

